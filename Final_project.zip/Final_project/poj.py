import login
import first_page
from multi_purpose_project import  ms, wb,vidpla
from games import game,game_2048, quiz_game, puzzle_game, snake_game
"""
imaginary_tech_root=Tk()
# width x height
imaginary_tech_root.geometry("670 x 480")
# width, height
imaginary_tech_root.minsize("300  ,100")
# width, height
imaginary_tech_root.maxsize("1200 , 990")
sona=label(text="First Tab")
sona.pack()
imaginary_tech_root.mainloop()
"""



