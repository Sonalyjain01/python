import tkinter as tk
root=tk.Tk()
root.geometry("800x400")
root .title("Fuzzy World")
main_frame=tk.Frame(root)

page_1=tk.Frame(main_frame)
page_1_lb=tk.Label(page_1,text='Home',font=('Bold',20)) 
page_1_lb.pack()
page_1.pack(pady=100)
main_frame.pack(fill=tk.BOTH,expand=True)

def open_music_player():
    # Implement the logic to open the music player here
    print("Music Player button clicked!")

def open_games():
    # Implement the logic to open the games here
    print("Games button clicked!")

def open_web_browser():
    # Implement the logic to open the web browser here
    print("Web Browser button clicked!")

def open_video_player():
    # Implement the logic to open the video player here
    print("Video Player button clicked!")

bottom_frame=tk.Frame(root)
music_player_btn=tk.Button(bottom_frame,text='Music Player',
                   font=("Bold",12),
                   bg='#1877f2',fg='white',width=12,
                   command=open_music_player)
music_player_btn.pack(side=tk.LEFT,padx=35)

video_player_btn=tk.Button(bottom_frame,text='Video Player',
                   font=("Bold",12),
                   bg='#1877f2',fg='white',width=12,
                   command=open_video_player)
video_player_btn.pack(side=tk.LEFT,padx=35)

web_browser_btn=tk.Button(bottom_frame,text='Web Browser',
                   font=("Bold",12),
                   bg='#1877f2',fg='white',width=12,
                   command=open_web_browser)
web_browser_btn.pack(side=tk.RIGHT,padx=35)

games_btn=tk.Button(bottom_frame,text='Games',
                   font=("Bold",12),
                   bg='#1877f2',fg='white',width=12,
                   command=open_games)
games_btn.pack(side=tk.RIGHT,padx=25)

bottom_frame.pack(side=tk.BOTTOM,pady=36,padx=30)
root.mainloop()
